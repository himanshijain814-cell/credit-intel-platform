-- Minimal schema (Postgres)
CREATE TABLE IF NOT EXISTS raw_news (
  id SERIAL PRIMARY KEY,
  issuer TEXT,
  source TEXT,
  url TEXT UNIQUE,
  published_at TIMESTAMPTZ,
  title TEXT,
  summary TEXT,
  raw_html BYTEA,
  content_hash TEXT,
  inserted_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS market_prices (
  ts TIMESTAMPTZ,
  ticker TEXT,
  open NUMERIC, high NUMERIC, low NUMERIC, close NUMERIC, volume BIGINT,
  PRIMARY KEY (ts, ticker)
);

CREATE TABLE IF NOT EXISTS issuer_features (
  asof TIMESTAMPTZ,
  issuer TEXT,
  feature JSONB,
  PRIMARY KEY (asof, issuer)
);

CREATE TABLE IF NOT EXISTS issuer_scores (
  asof TIMESTAMPTZ,
  issuer TEXT,
  model_version TEXT,
  score NUMERIC,
  band TEXT,
  short_trend NUMERIC,
  long_trend NUMERIC,
  PRIMARY KEY (asof, issuer, model_version)
);
