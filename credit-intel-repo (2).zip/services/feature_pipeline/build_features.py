# Example feature builder - connects to Postgres and writes an issuer_features row
import pandas as pd
import json
import os
from sqlalchemy import create_engine
from datetime import datetime

DB_URL = os.getenv('DATABASE_URL','postgresql://postgres:secret@localhost:5432/postgres')
engine = create_engine(DB_URL)

def build_for(issuer='AAPL'):
    # Very minimal example: read last two prices and create returns
    prices = pd.read_sql("SELECT * FROM market_prices WHERE ticker=%s ORDER BY ts DESC LIMIT 21", engine, params=(issuer,))
    if prices.empty:
        print('no prices')
        return
    prices = prices.sort_values('ts')
    prices['ret_1d'] = prices['close'].pct_change()
    latest = prices.iloc[-1]
    features = {
        'ret_1d': float(latest.get('ret_1d') or 0.0),
        'vol_20d': float(prices['close'].pct_change().rolling(20).std().iloc[-1] or 0.0)
    }
    asof = latest['ts'] if 'ts' in latest else datetime.utcnow()
    with engine.begin() as conn:
        conn.execute(
            "INSERT INTO issuer_features(asof, issuer, feature) VALUES (%s,%s,%s) ON CONFLICT (asof, issuer) DO UPDATE SET feature = EXCLUDED.feature",
            (asof, issuer, json.dumps(features))
        )
    print('features written for', issuer)

if __name__ == '__main__':
    build_for()
