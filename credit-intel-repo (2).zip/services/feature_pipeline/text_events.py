# Simple text event extractor and sentiment
import re
from bs4 import BeautifulSoup
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

EVENT_PATTERNS = {
    'guidance_cut': r"(lowered|cut|reduc(e|ed) guidance|revised downward guidance)",
    'downgrade': r"(downgraded|rating cut|lowered rating)",
    'lawsuit': r"(lawsuit|class action|investigation)",
    'default': r"(default|missed payment)",
    'layoff': r"(layoff|workforce reduction|restructuring)"
}

analyzer = SentimentIntensityAnalyzer()

def extract_events(html: bytes):
    soup = BeautifulSoup(html or b'', 'html.parser')
    text = soup.get_text(' ')
    sent = analyzer.polarity_scores(text)['compound']
    matches = []
    for k, pat in EVENT_PATTERNS.items():
        if re.search(pat, text, flags=re.I):
            matches.append(k)
    return sent, matches
