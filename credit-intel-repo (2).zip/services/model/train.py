# Training stub - expects a training_set.parquet in the working directory
import pandas as pd
import joblib
from lightgbm import LGBMRegressor
import os

if not os.path.exists('training_set.parquet'):
    print('No training set found. Create training_set.parquet with features + target to train.')
else:
    df = pd.read_parquet('training_set.parquet')
    X = df.drop(columns=['target','issuer','asof'], errors='ignore')
    y = df['target']
    if X.shape[0] < 10:
        print('Not enough rows to train; need >=10')
    else:
        model = LGBMRegressor(n_estimators=200)
        model.fit(X, y)
        joblib.dump(model, 'model.joblib')
        print('model.joblib saved')
