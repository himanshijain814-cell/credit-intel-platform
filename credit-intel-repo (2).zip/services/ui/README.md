UI placeholder. Use any React scaffold. Minimal instructions:

1) Create React app (Vite recommended)
2) Implement calls to /score and /scores endpoints
3) Add charts (Plotly) and a page to show top drivers and event timeline
