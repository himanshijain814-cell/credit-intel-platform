# FastAPI scoring endpoint (simple)
from fastapi import FastAPI
from pydantic import BaseModel
import joblib, os
import pandas as pd
import shap

app = FastAPI()

MODEL_PATH = os.getenv('MODEL_PATH','./services/model/model.joblib')
model = None
explainer = None
if os.path.exists(MODEL_PATH):
    model = joblib.load(MODEL_PATH)
    try:
        explainer = shap.TreeExplainer(model)
    except Exception:
        explainer = None

class FeatureIn(BaseModel):
    issuer: str
    features: dict

@app.get('/')
def home():
    return {'ok': True, 'model_loaded': bool(model)}

@app.post('/score')
def score(fi: FeatureIn):
    X = pd.DataFrame([fi.features])
    if model is None:
        return {'error': 'no model available', 'features': fi.features}
    s = float(model.predict(X)[0])
    shap_map = {}
    if explainer is not None:
        try:
            sv = explainer.shap_values(X)
            shap_map = {c: float(v) for c, v in zip(X.columns, sv[0])}
        except Exception:
            shap_map = {}
    top = sorted(shap_map.items(), key=lambda x: abs(x[1]), reverse=True)[:6]
    band = 'A' if s>=80 else 'BBB' if s>=65 else 'BB' if s>=50 else 'B' if s>=35 else 'CCC'
    return {'issuer': fi.issuer, 'score': s, 'band': band, 'top_drivers': [{'feature':k,'shap':v,'direction': 'pos' if v>0 else 'neg'} for k,v in top]}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8000)
