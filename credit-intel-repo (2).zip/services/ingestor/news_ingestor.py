# Simple RSS news ingestor example
import feedparser, hashlib, time, requests, os
from datetime import datetime, timezone
import psycopg2

FEEDS = {
    'AAPL': [
        'https://www.reutersagency.com/feed/?best-topics=company&post_type=best',
    ]
}

def sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()

DB_DSN = os.getenv('DATABASE_URL','postgresql://postgres:secret@localhost:5432/postgres')

def insert_news(conn, issuer, source, link, title, published, html, key):
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO raw_news(issuer, source, url, published_at, title, raw_html, content_hash)
            VALUES(%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (url) DO NOTHING
            """,
            (issuer, source, link, published, title, html, key)
        )
    conn.commit()

def run():
    conn = psycopg2.connect(DB_DSN)
    while True:
        for issuer, feeds in FEEDS.items():
            for url in feeds:
                try:
                    d = feedparser.parse(url)
                except Exception as e:
                    print('feed error', e)
                    continue
                for e in d.entries:
                    link = getattr(e, 'link', None)
                    title = getattr(e, 'title', '')
                    published = None
                    if getattr(e, 'published_parsed', None):
                        published = datetime.fromtimestamp(time.mktime(e.published_parsed), tz=timezone.utc)
                    key = sha(link or title)
                    try:
                        html = requests.get(link, timeout=10).content if link else b''
                    except Exception:
                        html = b''
                    insert_news(conn, issuer, url.split('/')[2] if '/' in url else url, link, title, published, html, key)
        print('sleeping 300s')
        time.sleep(300)

if __name__ == '__main__':
    run()
