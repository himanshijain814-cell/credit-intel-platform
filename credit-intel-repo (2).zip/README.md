# Real-Time Explainable Credit Intelligence Platform (MVP)

This repository contains a runnable MVP scaffold for the hackathon solution described in the brief.
It includes simple ingestion, feature building, a model training stub, a FastAPI scoring endpoint,
a React UI placeholder, and docker-compose for local runs.

**Contents**
- services/ingestor/news_ingestor.py  — RSS news ingestor (example)
- services/feature_pipeline/text_events.py — simple text event & sentiment extractor
- services/feature_pipeline/build_features.py — example feature builder
- services/model/train.py — training stub (LightGBM)
- services/api/main.py — FastAPI scoring endpoint using a saved model
- services/ui/README.md — placeholder with instructions to add UI
- docker-compose.yml — minimal compose to run DB + api + ingestor
- schema.sql — DB schema to initialize Postgres
- requirements.txt — Python deps for services
- LICENSE (MIT)

**How to run (local dev)**
1. Create a Python venv and install requirements:
   ```bash
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Initialize Postgres (or run with Docker Compose):
   ```bash
   psql postgres://postgres:secret@localhost:5432/postgres -f schema.sql
   ```
3. Run the API:
   ```bash
   python services/api/main.py
   ```
4. Run the ingestor (it will attempt to connect to the DB defined in the file):
   ```bash
   python services/ingestor/news_ingestor.py
   ```

This scaffold is intended as a clear starting point. Replace feeds, credentials and model artifacts with production-grade sources before public deployment.
